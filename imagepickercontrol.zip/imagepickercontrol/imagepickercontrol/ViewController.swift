//
//  ViewController.swift
//  imagepickercontrol
//
//  Created by MACOS on 11/19/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    let picke = UIImagePickerController();
    
    @IBOutlet weak var img: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        img.image = info[UIImagePickerControllerOriginalImage] as! UIImage?;
        
        img.contentMode = .scaleAspectFit;
        
        self.dismiss(animated: true, completion: nil);
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    
    }


    @IBAction func btnclick(_ sender: AnyObject) {
        
        picke.sourceType = UIImagePickerControllerSourceType.photoLibrary;
        picke.delegate = self;
    
        self.present(picke, animated: true, completion: nil);
    }
}

